const express = require("express");
const router = express.Router();
const conexao = require("./conexao");

// Rota para renderizar o formulário de cadastro
router.get('/cadastro', (req, res) => {
  res.render('cadastro');
});

// Rota para lidar com o envio do formulário de cadastro
router.post('./cadastro', (req, res) => {
  const { nome, email, senha } = req.body;

  const sqlInserirUsuario = 'INSERT INTO USUARIO (EMAIL_USUARIO, SENHA_USUARIO, NOME_USUARIO) VALUES (?, ?, ?)';
  conexao.query(sqlInserirUsuario, [email, senha, nome], (erro, resultado) => {
    if (erro){
      console.error("Erro ao inserir o usuário:", erro);
      res.status(500).send('Erro ao cadastrar usuário');
      return;
    }
    console.log("Usuário inserido com sucesso!");
    res.send('Usuário cadastrado com sucesso!');
  });
});

module.exports = router;
