const express = require("express");
const router = express.Router();
const conexao = require("./conexao");

// Rota para renderizar o formulário de login
router.get('/login', (req, res) => {
  res.render('login');
});

// Rota para lidar com o envio do formulário de login
router.post('/login', (req, res) => {
  const { email, senha } = req.body;

  const sqlConferirUsuario = 'SELECT * FROM USUARIO WHERE EMAIL_USUARIO = ? AND SENHA_USUARIO = ?';
  conexao.query(sqlConferirUsuario, [email, senha], (erro, resultado) => {
    if (erro) {
      console.error("Erro ao consultar o usuário:", erro);
      res.status(500).send('Erro ao verificar usuário');
      return;
    }

    // Verifica se o usuário foi encontrado no banco de dados
    if (resultado.length > 0) {
      // Usuário encontrado, faça algo, como redirecionar para uma página de perfil
      res.send('Login bem-sucedido! Redirecionando...');
    } else {
      // Usuário não encontrado, exiba uma mensagem de erro ou redirecione para uma página de erro
      res.send('Usuário não encontrado. Verifique suas credenciais.');
    }
  });
});

module.exports = router;
