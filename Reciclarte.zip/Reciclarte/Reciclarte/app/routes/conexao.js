const mysql = require('mysql');

const conexao = mysql.createConnection({
  host: 'reciclarte.mysql.uhserver.com',
  user: 'reciclarte',
  password: '1qa2ws3ed@@',
  database: 'reciclarte'
});

conexao.connect((erro) => {
  if (erro) {
    console.error('Erro ao conectar ao banco de dados:', erro);
    return;
  }
  console.log('Conexão ao banco de dados MySQL estabelecida com sucesso!');
});

module.exports = conexao;
